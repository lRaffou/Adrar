<?php
$_ENV['host'] = 'localhost';
$_ENV['dbname'] = 'utilisateur';
$_ENV['login'] = 'root';
$_ENV['password'] = 'root';

?>