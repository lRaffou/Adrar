<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<nav>
        <a href="/Demo/Routeur/">Accueil</a>
        <a href="/Demo/Routeur/Tata">Mon Compte</a>
    </nav>
    <h1>Accueil</h1>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Blanditiis sapiente modi delectus nihil quod iusto quos perferendis neque, perspiciatis animi! Voluptas repellat non quas voluptates earum ducimus, ab possimus. Exercitationem!</p>
</body>
</html>